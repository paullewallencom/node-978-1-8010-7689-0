module.exports={
    PORT: 8000,
    DB: 'mongodb://localhost/products'
}